from pymongo import MongoClient
import jieba as jieba
import time
import requests
import json
import pandas as pd
import random
import numpy as np
import PIL.ImageFile as ImageFile
import random
from urllib import request
from urllib.request import Request, urlopen
# https://www.dcard.tw/service/api/v2/forums/talk/posts?popular=true&limit=30&before=235999153
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', "Referer": "https://www.dcard.tw/service/api/v2/forums/talk/posts?limit=30"}
alldata = []
last_article = ''
url = 'https://www.dcard.tw/service/api/v2/forums/talk/posts?limit=30'
for i in range(30):
    if i != 0:  # 判斷是否是第一次執行
        request_url = url + '&before=' + str(last_article)
    else:
        request_url = url  # 第一次執行，不須加上後方的before
    t = 0.1
    time.sleep(t)
    list_req = Request(
        request_url, headers=headers)  # 請求
    # list_req.add_header('User-Agent', random.choice(my_headers))
    # 將整個網站的程式碼爬下來
    getdata = json.loads(urlopen(list_req).read())
    alldata.extend(getdata)  # 將另一個陣列插在最後面
    last_article = getdata[-1]['id']  # 取出最後一篇文章
    print(last_article)
    time.sleep(random.uniform(5, 15))
    print('done')

alldata = pd.DataFrame(alldata)
# 翻譯欄位
alldata.rename(columns={
    'id': '文章ID',
    'title': '標題',
    'excerpt': '內文簡介',
    'anonymousSchool': '學校匿名',
    'anonymousDepartment': '個人主頁顯示',
    'forumId': '版ID',
    'replyId': '回應的文章ID',
    'createdAt': '發文時間',
    'updatedAt': '更新時間',
    'commentCount': '回覆數',
    'likeCount': '按讚數',
    'topics': '主題標籤',
    'forumName': '版中文名',
    'forumAlias': '版英文名',
    'gender': '作者性別',
    'school': '作者學校',
    'replyTitle': '回應的文章的標題',
    'layout': '頁面版型',
    'withImages': '是否使用圖片',
    'withVideos': '是否使用影片',
    'media': '媒體連結',
    'department': '個人主頁',
    'categories': '類別',
    'link': '連結（版型為連結才有）'
}, inplace=True)
# 存檔
alldata.to_csv(
    'Dcard文章資料5.csv',  # 檔案名稱
    encoding='utf-8-sig',  # 編碼
    index=False  # 是否保留index
)

dcard_data = pd.read_csv('Dcard文章資料5.csv')
dcard_data = dcard_data[['文章ID', '標題', '內文簡介', '版ID', '回應的文章ID',
                        '發文時間', '回覆數', '按讚數', '主題標籤', '版中文名', '回應的文章的標題', '媒體連結']]
dcard_data = dcard_data.drop_duplicates()
dcard_data.info()
dcard_data['發文時間'] = pd.to_datetime(dcard_data['發文時間'])
dcard_data.info()
dcard_data['所有文'] = dcard_data['標題'] + dcard_data['內文簡介']
removeword = ['span', 'class', 'f3', 'https', 'imgur', 'h1', '_   blank', 'href', 'rel', 'nofollow', 'target', 'cdn', 'cgi', 'b4', 'jpg', 'hl', 'b1', 'f5', 'f4',
              'goo.gl', 'f2', 'email', 'map', 'f1', 'f6', '__cf___', 'data', 'bbs''html', 'cf', 'f0', 'b2', 'b3', 'b5', 'b6', '原文內容', '原文連結', '作者'
              '標題', '時間', '看板', '<', '>', '，', '。', '？', '—', '閒聊', '・', '/', ' ', '=', '\"', '\n', '」', '「', '！', '[', ']', '：', '‧', '╦', '╔', '╗', '║', '╠', '╬', '╬', ':', '╰', '╩', '╯', '╭', '╮', '│', '╪', '─', '《', '》', '.', '、', '（', '）', '　', '*', '※', '~', '○', '”', '“', '～', '@', '＋', '\r', '▁', ')', '(', '-', '═', '?', ',', '!', '…', '&', ';', '『', '』', '#', '＝', '＃', '\\', '\\n', '"', '的', '^', '︿', '＠', '$', '＄', '%', '％',
              '＆', '＊', '＿', '+', "'", '{', '}', '｛', '｝', '|', '｜', '．', '‵', '`', '；', '●', '§', '※', '○', '△', '▲', '◎', '☆', '★', '◇', '◆', '□', '■', '▽',
              '▼', '㊣', '↑', '↓', '←', '→', '↖', '【', '】'
              ]
for word in removeword:
    dcard_data['所有文'] = dcard_data['所有文'].str.replace(word, '')

jieba.set_dictionary('dict.txt.big')
jieba.load_userdict('user_dict.txt')
dcard_data = dcard_data.dropna(subset=["所有文"])
dcard_data['關鍵字'] = dcard_data['所有文'].apply(lambda x: list(jieba.cut(x)))
dcard_data.info()


dcard_data.to_csv('Dcard文章資料5_Clear.csv',
                  encoding='UTF-8-sig')

# 存檔MongoDB


# client = MongoClient(host='localhost', port=27017)  # 连接mongodb端口

# db = client.Test
# crowd = db.data  # crowd表格

# # 将dataframe格式的user_review插入到crowd中
# crowd.insert_many(json.loads(dcard_data.T.to_json()).values())
