export const mealImgs = [
  { id: 1, name: "嫩煎魚排佐鮮蔬", url: "https://i.imgur.com/o8cd4Rw.jpg" },
  { id: 2, name: "鮮蝦河粉", url: "https://i.imgur.com/WY8DRvv.jpg" },
  { id: 3, name: "清炒番茄拉", url: "https://i.imgur.com/Yg1t5sW.jpg" },
  { id: 5, name: "九層塔沙拉", url: "https://i.imgur.com/KRboztK.jpg" },
  { id: 4, name: "澳洲牛排佐松露醬", url: "https://i.imgur.com/uzJbxW5.jpg" },
];

export const datas = [
  {
    id: 1,
    name: "嫩煎魚排佐鮮蔬",
    price: 350,
    url: "https://i.imgur.com/o8cd4Rw.jpg",
  },
  {
    id: 2,
    name: "鮮蝦河粉",
    price: 280,
    url: "https://i.imgur.com/WY8DRvv.jpg",
  },
];
