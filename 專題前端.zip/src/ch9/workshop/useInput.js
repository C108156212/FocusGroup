import { useState, useEffect } from "react";

const useInput = (initalValue, isRequired = false) => {
  const [value, setValue] = useState(initalValue);
  const [error, setError] = useState(null);

  const reset = () => {
    setValue(initalValue);
  };

  const handleChange = (e) => {
    const { type, value, checked } = e.target;
    setValue(type === "checkbox" ? checked : value);
  };

  useEffect(() => {
    if (isRequired && (value === null || value === "" || value === undefined)) {
      setError("此欄位為必填欄位");
    } else {
      setError(null);
    }
  }, [value, isRequired]);

  return {
    value,
    error,
    handleChange,
    reset,
  };
};

export default useInput;
