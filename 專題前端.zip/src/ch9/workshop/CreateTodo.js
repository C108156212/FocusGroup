import React from "react";
import useInput from "./useInput";

const CreateTodo = (props) => {
  const { onAdd } = props;
  const {
    value: title,
    handleChange: handleTitleChange,
    reset: resetTitle,
  } = useInput("");
  const {
    value: completed,
    handleChange: handleCompletedChange,
    reset: resetCompleted,
  } = useInput(false);

  const handleAddTodo = (e) => {
    e.preventDefault();

    onAdd({ title: title, completed: completed });

    resetTitle();
    resetCompleted();
  };

  return (
    <div>
      <h1>新增待辦</h1>
      <form onSubmit={handleAddTodo}>
        <div>
          <label style={{ marginRight: 10 }}>標題</label>
          <input
            type="text"
            name="title"
            onChange={handleTitleChange}
            value={title}
          />
        </div>
        <div style={{ paddingTop: 10 }}>
          <label style={{ marginRight: 10 }}>是否完成</label>
          <input
            type="checkbox"
            name="completed"
            onChange={handleCompletedChange}
            checked={completed}
          />
        </div>
        <div style={{ paddingTop: 10 }}>
          <input type="submit" value="新增" />
        </div>
      </form>
    </div>
  );
};

export default CreateTodo;
