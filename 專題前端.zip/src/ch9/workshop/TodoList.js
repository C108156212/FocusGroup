import React from "react";
import { Link, Switch, Route, BrowserRouter } from "react-router-dom";
import { useState } from "react";
import UnCompletedList from "./UnCompletedList";
import CompletedList from "./CompletedList";
import CreateTodo from "./CreateTodo";

const TodoList = () => {
  const [todos, setTodos] = useState([
    { id: 1, title: "delectus aut autem", completed: true },
    { id: 2, title: "quis ut nam facilis et officia qui", completed: false },
    { id: 3, title: "fugiat veniam minus", completed: false },
    { id: 4, title: "et porro tempora", completed: true },
    {
      id: 5,
      title: "laboriosam mollitia et enim quasi adipisci",
      completed: false,
    },
  ]);

  const unCompletedTodos = todos.filter((todo) => todo.completed === false);
  const completedTodos = todos.filter((todo) => todo.completed === true);

  const handleClick = (id, isCompleted, e) => {
    e.preventDefault();
    const newTodos = todos.map((todo) => {
      return todo.id === id ? { ...todo, completed: isCompleted } : todo;
    });

    setTodos(newTodos);
  };

  const handleAddTodo = (todo) => {
    setTodos((preTodos) => {
      return [
        ...preTodos,
        {
          id: preTodos[preTodos.length - 1].id + 1,
          ...todo,
        },
      ];
    });
  };

  return (
    <BrowserRouter>
      <div>
        <Link style={{ marginRight: 10 }} to="create-todo">
          新增待辦
        </Link>
        <Link to="/completed" style={{ marginRight: "10px" }}>
          已完成
        </Link>
        <Link to="/un-complted">未完成</Link>
      </div>
      <Switch>
        <Route path="/create-todo">
          <CreateTodo onAdd={handleAddTodo} />
        </Route>
        <Route path="/completed">
          <CompletedList todos={completedTodos} onClick={handleClick} />
        </Route>
        <Route path="/un-complted">
          <UnCompletedList todos={unCompletedTodos} onClick={handleClick} />
        </Route>
        <Route
          render={() => {
            return (
              <div>
                <h1>Oops，發生了一點問題</h1>
                <div style={{ color: "#bdbdbd" }}>
                  尚未載入或找不到指定的頁面
                </div>
              </div>
            );
          }}
        />
      </Switch>
    </BrowserRouter>
  );
};

export default TodoList;
