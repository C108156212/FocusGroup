import CompletedItem from "../CompletedItem";

export default function CompletedList(props) {
  return (
    <div>
      <h1>已完成項目</h1>
      {props.todos.map((todo) => (
        <CompletedItem todo={todo} onClick={props.onClick} />
      ))}
    </div>
  );
}
