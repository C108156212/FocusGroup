import React from "react";

export default class CreateTodo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "",
      completed: false,
    };
  }

  handleChange = (e) => {
    const { type, name, value, checked } = e.target;
    this.setState({
      [name]: type === "checkbox" ? checked : value,
    });
  };

  handleAddTodo = (e) => {
    e.preventDefault();
    const { onAdd } = this.props;
    onAdd({ ...this.state });
    this.setState({
      title: "",
      completed: false,
    });
  };

  render() {
    const { handleChange, handleAddTodo } = this;
    const { title, completed } = this.state;
    return (
      <div>
        <h1>新增待辦</h1>
        <form onSubmit={handleAddTodo}>
          <div>
            <label style={{ marginRight: 10 }}>標題</label>
            <input
              type="text"
              name="title"
              onChange={handleChange}
              value={title}
            />
          </div>
          <div style={{ paddingTop: 10 }}>
            <label style={{ marginRight: 10 }}>是否完成</label>
            <input
              type="checkbox"
              name="completed"
              onChange={handleChange}
              checked={completed}
            />
          </div>
          <div style={{ paddingTop: 10 }}>
            <input type="submit" value="新增" />
          </div>
        </form>
      </div>
    );
  }
}
