import React from "react";
import { Link, Switch, Route } from "react-router-dom";
import UnCompletedList from "./UnCompletedList";
import CompletedList from "./CompletedList";
import CreateTodo from "./CreateTodo";

class TodoList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: [
        { id: 1, title: "delectus aut autem", completed: true },
        {
          id: 2,
          title: "quis ut nam facilis et officia qui",
          completed: false,
        },
        { id: 3, title: "fugiat veniam minus", completed: false },
        { id: 4, title: "et porro tempora", completed: true },
        {
          id: 5,
          title:
            "laboriosam mollitia et enim quasi adipisci quia provident illum",
          completed: false,
        },
      ],
    };
  }

  handleClick = (id, isCompleted, e) => {
    e.preventDefault();
    const { todos } = this.state;
    this.setState({
      todos: todos.map((todo) => {
        return todo.id === id ? { ...todo, completed: isCompleted } : todo;
      }),
    });
  };

  handleAddTodo = (todo) => {
    this.setState((preState) => {
      const { todos } = preState;
      return {
        todos: [
          ...todos,
          {
            id: todos[todos.length - 1].id + 1,
            ...todo,
          },
        ],
      };
    });
  };

  render() {
    const { handleAddTodo, handleClick } = this;
    const { todos } = this.state;
    const uncompletedTodos = todos.filter((todo) => {
      return !todo.completed;
    });
    const completedTodos = todos.filter((todo) => {
      return todo.completed;
    });
    return (
      <div>
        <div style={{ padding: 10 }}>
          <Link style={{ marginRight: 10 }} to="create-todo">
            新增待辦
          </Link>
          <Link style={{ marginRight: 10 }} to="un-completed">
            未完成
          </Link>
          <Link style={{ marginRight: 10 }} to="completed">
            已完成
          </Link>
        </div>
        <div style={{ padding: 10 }}>
          <Switch>
            <Route path="/create-todo">
              <CreateTodo onAdd={handleAddTodo} />
            </Route>
            <Route path="/un-completed">
              <UnCompletedList todos={uncompletedTodos} onClick={handleClick} />
            </Route>
            <Route path="/completed">
              <CompletedList todos={completedTodos} onClick={handleClick} />
            </Route>
            <Route
              render={() => {
                return (
                  <div>
                    <h1>Oops，發生了一點問題</h1>
                    <div style={{ color: "#bdbdbd" }}>
                      尚未載入或找不到指定的頁面
                    </div>
                  </div>
                );
              }}
            />
          </Switch>
        </div>
      </div>
    );
  }
}
export default TodoList;
