import Practice1 from "./workshop/practice1";

export default Practice1;
