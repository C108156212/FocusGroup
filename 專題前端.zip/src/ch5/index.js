import Practice2 from "./workshop/TodoList";

export default Practice2;
