import React, { Component } from "react";
import TodoItem from "./TodoItem";

export default class TodoList extends Component {
  // 宣告 Todo 資料
  todos = [
    { id: 1, title: "delectus aut autem", completed: false },
    { id: 2, title: "quis ut nam facilis et officia qui", completed: false },
    { id: 3, title: "fugiat veniam minus", completed: false },
    { id: 4, title: "et porro tempora", completed: true },
    {
      id: 5,
      title: "laboriosam mollitia et enim quasi adipisci quia provident illum",
      completed: false,
    },
  ];
  render() {
    return (
      <div>
        <h1>待辦清單</h1>
        <div>
          {this.todos.map(function (todo) {
            return <TodoItem key={todo.id} todo={todo} />;
          })}
        </div>
      </div>
    );
  }
}
