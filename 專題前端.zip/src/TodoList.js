import React, { useState } from "react";
import { Button, List, Radio, Input } from "antd";
import TodoListItem from "./TodoListItem";
import { PlusOutlined } from "@ant-design/icons";
import CreateTodoModal from "./CreateTodoModal";
const { Search } = Input;

const TodoList = (props) => {
  const { todos, onCompleteChange, onAddTodo } = props;
  const [searchTodo, setsearchTodo] = useState(todos);
  const [queryType, setQueryType] = useState("all");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchValue, setSearchValue] = useState({
    name: "",
    price: "",
  });

  const handleQueryTypeChange = (e) => {
    setQueryType(e.target.value);
  };

  const getTodos = () => {
    switch (queryType) {
      case "completed":
        return searchTodo.filter((todo) => todo.completed);
      case "uncompleted":
        return searchTodo.filter((todo) => !todo.completed);
      case "all":
      default:
        return searchTodo;
    }
  };

  const handleOpenTodoModal = (e) => {
    setShowCreateModal(true);
  };

  const handleCancel = (e) => {
    setShowCreateModal(false);
  };

  const handleAddTodo = (todo) => {
    onAddTodo(todo);
    setShowCreateModal(false);
  };

  const handleSearchChange = (e) => {
    const { name, value } = e.target;
    setSearchValue({
      ...searchValue,
      [name]: value,
    });
  };

  const doEnter = (e) => {
    console.log(searchValue.name);
    e.preventDefault();
    // const searchs = todos.filter((todo) => todo.title === searchValue.name);
    // console.log(searchs);
    // setsearchTodo({
    //   ...searchTodo,
    //   searchTodo: searchs,
    // });
    return todos.filter((searchTodo) => searchTodo.title === searchValue.name);
    console.log(searchTodo);
  };

  return (
    <div>
      <CreateTodoModal
        visible={showCreateModal}
        onAddTodo={handleAddTodo}
        onCancel={handleCancel}
      />
      <div>
        <form onSubmit={doEnter}>
          <p>
            <label>查詢</label>
            <input
              name="name"
              value={searchValue.name}
              onChange={handleSearchChange}
            />
            <input type="submit" value="Search" />
          </p>
        </form>
      </div>
      <div style={{ margin: "10px 0px", display: "flex" }}>
        <Radio.Group
          value={queryType}
          buttonStyle="solid"
          onChange={handleQueryTypeChange}
        >
          <Radio.Button value="all">全部</Radio.Button>
          <Radio.Button value="completed">已完成</Radio.Button>
          <Radio.Button value="uncompleted">未完成</Radio.Button>
        </Radio.Group>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          style={{ marginLeft: "auto" }}
          onClick={handleOpenTodoModal}
        >
          新增待辦
        </Button>
      </div>
      <List
        grid={{ gutter: 16, column: 4 }}
        dataSource={getTodos()}
        renderItem={(todo) => (
          <List.Item>
            <TodoListItem todo={todo} onCompleteChange={onCompleteChange} />
          </List.Item>
        )}
      />
    </div>
  );
};

export default TodoList;
