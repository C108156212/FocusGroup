import { Component } from "react";
import UnCompletedList from "./UnCompletedList";
import CompletedList from "./CompletedList";
import { BrowserRouter, Switch, Route, Link } from "react-router-dom";

export default class TodoList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: [
        { id: 1, title: "delectus aut autem", completed: true },
        {
          id: 2,
          title: "quis ut nam facilis et officia qui",
          completed: false,
        },
        { id: 3, title: "fugiat veniam minus", completed: false },
        { id: 4, title: "et porro tempora", completed: true },
        {
          id: 5,
          title: "laboriosam mollitia et enim quasi adipisci",
          completed: false,
        },
      ],
    };
  }

  handleClick = (id, isCompleted, e) => {
    e.preventDefault();
    const newTodos = this.state.todos.map((todo) => {
      return todo.id === id ? { ...todo, completed: isCompleted } : todo;
    });

    this.setState({
      todos: newTodos,
    });
  };

  render() {
    const unCompletedTodos = this.state.todos.filter(
      (todo) => todo.completed === false
    );
    const completedTodos = this.state.todos.filter(
      (todo) => todo.completed === true
    );
    return (
      <BrowserRouter>
        <div>
          <div>
            <Link to="/completed" style={{ marginRight: "10px" }}>
              已完成
            </Link>
            <Link to="/un-complted">未完成</Link>
          </div>
          <Switch>
            <Route path="/completed">
              <CompletedList
                todos={completedTodos}
                onClick={this.handleClick}
              />
            </Route>
            <Route path="/un-complted">
              <UnCompletedList
                todos={unCompletedTodos}
                onClick={this.handleClick}
              />
            </Route>
            <Route
              render={() => {
                return (
                  <div>
                    <h1>Oops，發生了一點問題</h1>
                    <div style={{ color: "#bdbdbd" }}>
                      尚未載入或找不到指定的頁面
                    </div>
                  </div>
                );
              }}
            />
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}
