export default function Activities() {
  return <div>I am Activities</div>;
}
