export default function NotFound() {
  return <div>Sorry , Not found 404</div>;
}
