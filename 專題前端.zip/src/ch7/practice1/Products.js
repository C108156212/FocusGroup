export default function Products() {
  return <div>I am Products</div>;
}
