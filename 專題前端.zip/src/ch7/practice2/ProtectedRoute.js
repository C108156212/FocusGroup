import React from "react";
import { Route, Redirect } from "react-router-dom";

export default function ProtectedRoute(props) {
  const { component: Component, ...rest } = props;

  const isLogin = () => {
    // 一些檢查登入的邏輯
    return false;
  };

  return isLogin() ? (
    <Route component={Component} {...rest} />
  ) : (
    <Redirect to="/login" />
  );
}
