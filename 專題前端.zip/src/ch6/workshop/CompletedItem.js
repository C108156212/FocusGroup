export default function CompletedItem(props) {
  return (
    <div>
      <span>{props.todo.title}</span>
      &nbsp;&nbsp;
      <a href="#" onClick={(e) => props.onClick(props.todo.id, false, e)}>
        未完成
      </a>
    </div>
  );
}
