import UnCompletedItem from "./UnCompletedItem";
export default function UnCompletedList(props) {
  return (
    <div>
      <h1>未完成項目</h1>
      {props.todos.map((todo) => (
        <UnCompletedItem todo={todo} />
      ))}
    </div>
  );
}
