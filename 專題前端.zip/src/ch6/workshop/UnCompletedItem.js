export default function UnCompletedItem(props) {
  return (
    <div>
      <span>{props.todo.title}</span>
      &nbsp;&nbsp;
      <a href="#" onClick={(e) => props.onClick(props.todo.id, true, e)}>
        已完成
      </a>
    </div>
  );
}
