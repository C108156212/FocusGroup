export const LOGIN_IN_DOING = 'LOGIN_IN_DOING';
export const LOGIN_IN_DONE = 'LOGIN_IN_DONE';
export const LOGIN_IN_ERROR = 'LOGIN_IN_ERROR';
