export const REG_DOING = 'REG_DOING';
export const REG_DONE = 'REG_DONE';
export const REG_ERROR = 'REG_ERROR';
