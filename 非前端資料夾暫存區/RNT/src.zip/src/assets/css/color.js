export const THEME = '#92a8d1';
export const THEME_BACKGROUND = '#f5f5f5';
export const THEME_LABEL = '#56688a';
export const THEME_TEXT = '#8c8c8c';
